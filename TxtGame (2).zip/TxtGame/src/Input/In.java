package Input;

import java.util.Scanner;
/* Classe dedicata unicamente agli input degli utenti.
Si richiama così In. */
public class In {
public static Scanner scanner = new Scanner(System.in);
}
