package Main;
public class Main {
    public static void main(String[] args) throws Exception {
        GamePanel gamePanel = new GamePanel();

        gamePanel.startGame();
    }
}
